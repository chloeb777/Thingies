class Thingy
{
  private int myX, myY;
  public Thingy()
  {
    myX = myY = 0;
  }
  public void setX(int n_) {
    myX = n_;
  }
  public void setY(int n_) {
    myY = n_;
  }
  public int getX() {
    return myX;
  }
  public int getY() {
    return myY;
  }
}
